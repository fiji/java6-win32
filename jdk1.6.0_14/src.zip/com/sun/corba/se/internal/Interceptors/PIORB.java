/*
 * @(#)PIORB.java	1.66 05/11/17
 * 
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.corba.se.internal.Interceptors;

import com.sun.corba.se.internal.POA.POAORB;
             
/** 
 * Deprecated class for backward compatibility.
 */
public class PIORB 
    extends POAORB
{
    public PIORB() {
	super();
    }
}

// End of file.

